import React from 'react';
import ServerTable from './components/ServerTable';

function App() {
  return <ServerTable />;
}

export default App;